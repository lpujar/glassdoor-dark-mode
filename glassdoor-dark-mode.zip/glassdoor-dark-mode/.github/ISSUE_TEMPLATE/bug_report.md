---
name: Bug report
about: Something looks wrong or isn't working
labels: bug
---

**What happened?**

**What did you expect?**

**Page URL (e.g. company reviews, jobs, salaries):**

**Browser and version:**

**Screenshot (if it's a visual problem):**
