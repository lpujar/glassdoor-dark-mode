/**
 * Popup: reads and writes the same chrome.storage.sync settings the content script uses.
 * It never talks to the page directly, because the content script reacts to storage changes.
 */
(() => {
  "use strict";

  const { DEFAULTS, clamp } = GDDark;
  const $ = (id) => document.getElementById(id);
  const modeRadios = document.querySelectorAll('input[name="mode"]');

  function fill(settings) {
    const s = { ...DEFAULTS, ...settings };
    modeRadios.forEach((radio) => {
      radio.checked = radio.value === s.mode;
    });
    $("scheduleEnabled").checked = s.scheduleEnabled;
    $("scheduleStart").value = s.scheduleStart;
    $("scheduleEnd").value = s.scheduleEnd;
    $("brightness").value = s.brightness;
    $("contrast").value = s.contrast;
    $("brightnessOut").textContent = s.brightness;
    $("contrastOut").textContent = s.contrast;
    $("showButton").checked = s.showButton;
  }

  function save(patch) {
    chrome.storage.sync.set(patch);
  }

  // Sliders fire many events while dragging. Chrome limits sync writes per minute,
  // so we update the label instantly but save only after the user pauses.
  function debounce(fn, ms) {
    let timer;
    return (...args) => {
      clearTimeout(timer);
      timer = setTimeout(() => fn(...args), ms);
    };
  }

  function bindSlider(key) {
    const input = $(key);
    const out = $(`${key}Out`);
    const saveLater = debounce((value) => save({ [key]: value }), 150);
    input.addEventListener("input", () => {
      const value = clamp(input.value, 50, 150, 100);
      out.textContent = value;
      saveLater(value);
    });
  }

  modeRadios.forEach((radio) => {
    radio.addEventListener("change", () => save({ mode: radio.value }));
  });
  $("scheduleEnabled").addEventListener("change", (e) => {
    save({ scheduleEnabled: e.target.checked });
  });
  ["scheduleStart", "scheduleEnd"].forEach((key) => {
    $(key).addEventListener("change", (e) => {
      if (e.target.value) save({ [key]: e.target.value });
    });
  });
  $("showButton").addEventListener("change", (e) => save({ showButton: e.target.checked }));
  bindSlider("brightness");
  bindSlider("contrast");
  $("reset").addEventListener("click", () => {
    chrome.storage.sync.set(DEFAULTS, () => fill(DEFAULTS));
  });

  chrome.storage.sync.get(DEFAULTS, fill);
})();
