/**
 * Service worker. Its only job: when the keyboard shortcut is pressed,
 * tell the active tab's content script to toggle.
 */
"use strict";

chrome.commands.onCommand.addListener((command) => {
  if (command !== "toggle-dark-mode") return;

  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    const tab = tabs[0];
    if (!tab || tab.id === undefined) return;

    chrome.tabs.sendMessage(tab.id, { type: "toggle-dark-mode" }, () => {
      // On non-Glassdoor tabs nothing is listening. That's fine, so we ignore the error.
      if (chrome.runtime.lastError) {
        /* ignored */
      }
    });
  });
});
