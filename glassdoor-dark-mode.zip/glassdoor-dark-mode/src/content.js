/**
 * Runs inside Glassdoor pages.
 * Single source of truth: chrome.storage.sync. Everything (button, popup, shortcut)
 * changes the stored settings, and every tab re-renders when they change.
 */
(() => {
  "use strict";

  const { DEFAULTS, resolveDark, clamp } = GDDark;
  const DARK_CLASS = "gd-dark";
  const BTN_ID = "gd-dark-toggle";
  const root = document.documentElement;
  const systemQuery = window.matchMedia("(prefers-color-scheme: dark)");

  let settings = { ...DEFAULTS };
  let observedBody = null;
  let scheduled = false;

  function isDarkNow() {
    return resolveDark(settings, new Date(), systemQuery.matches);
  }

  /** Applies the current settings to the page. Safe to call as often as needed. */
  function render() {
    const dark = isDarkNow();
    root.classList.toggle(DARK_CLASS, dark);
    root.style.setProperty("--gd-brightness", clamp(settings.brightness, 50, 150, 100) / 100);
    root.style.setProperty("--gd-contrast", clamp(settings.contrast, 50, 150, 100) / 100);

    const btn = document.getElementById(BTN_ID);
    if (btn) {
      btn.hidden = !settings.showButton;
      btn.textContent = dark ? "☀️" : "🌙";
      btn.setAttribute("aria-pressed", String(dark));
      btn.setAttribute("aria-label", dark ? "Switch to light mode" : "Switch to dark mode");
      btn.title = "Toggle dark mode (Option+Shift+D)";
    }
  }

  /** Flip between explicit light and dark, and save it so all tabs follow. */
  function toggle() {
    const next = isDarkNow() ? "light" : "dark";
    settings = { ...settings, mode: next };
    render();
    chrome.storage.sync.set({ mode: next });
  }

  function ensureButton() {
    if (!document.body || document.getElementById(BTN_ID)) return;
    const btn = document.createElement("button");
    btn.id = BTN_ID;
    btn.type = "button";
    btn.addEventListener("click", toggle);
    document.body.appendChild(btn);
    render();
  }

  function observeBody() {
    if (!document.body || document.body === observedBody) return;
    observedBody = document.body;
    // Watch direct children of <body>: if the app removes our button, put it back.
    bodyObserver.observe(document.body, { childList: true });
  }

  /** Coalesce bursts of DOM changes into one check per animation frame. */
  function scheduleCheck() {
    if (scheduled) return;
    scheduled = true;
    requestAnimationFrame(() => {
      scheduled = false;
      observeBody();
      ensureButton();
      render(); // re-applies the class if the page's JS reset <html class="...">
    });
  }

  const bodyObserver = new MutationObserver(scheduleCheck);
  const rootObserver = new MutationObserver(scheduleCheck);

  function initDom() {
    ensureButton();
    observeBody();
    // <html> children changing (e.g. <body> replaced) or its class being rewritten.
    rootObserver.observe(root, {
      childList: true,
      attributes: true,
      attributeFilter: ["class"],
    });
  }

  // React to changes made from the popup, the shortcut, or another tab.
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== "sync") return;
    const updated = {};
    for (const [key, change] of Object.entries(changes)) {
      updated[key] = change.newValue === undefined ? DEFAULTS[key] : change.newValue;
    }
    settings = { ...settings, ...updated };
    render();
  });

  // Keyboard shortcut (background.js forwards it to the active tab).
  chrome.runtime.onMessage.addListener((message) => {
    if (message && message.type === "toggle-dark-mode") toggle();
  });

  // Follow the OS theme live, and re-check the schedule every minute.
  systemQuery.addEventListener("change", render);
  setInterval(render, 60 * 1000);

  // Start: load saved settings, apply them, then add the button when <body> exists.
  chrome.storage.sync.get(DEFAULTS, (stored) => {
    settings = { ...DEFAULTS, ...stored };
    render();
    if (document.readyState === "loading") {
      document.addEventListener("DOMContentLoaded", initDom);
    } else {
      initDom();
    }
  });
})();
