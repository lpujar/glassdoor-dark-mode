/**
 * Pure logic shared by the content script and the popup.
 * It has no browser APIs, so it can be unit-tested with plain Node (npm test).
 */
(function (root) {
  "use strict";

  const DEFAULTS = Object.freeze({
    mode: "auto", // "auto" | "light" | "dark"
    scheduleEnabled: false, // in auto mode: follow the schedule instead of the system theme
    scheduleStart: "19:00",
    scheduleEnd: "07:00",
    brightness: 100, // percent
    contrast: 100, // percent
    showButton: true,
  });

  /** "19:30" -> 1170 (minutes since midnight). Returns null if invalid. */
  function toMinutes(hhmm) {
    const match = /^(\d{1,2}):(\d{2})$/.exec(String(hhmm));
    if (!match) return null;
    const hours = Number(match[1]);
    const minutes = Number(match[2]);
    if (hours > 23 || minutes > 59) return null;
    return hours * 60 + minutes;
  }

  /** True if `now` falls inside [start, end). Handles overnight ranges like 19:00 -> 07:00. */
  function isInSchedule(now, start, end) {
    const s = toMinutes(start);
    const e = toMinutes(end);
    if (s === null || e === null || s === e) return false;
    const n = now.getHours() * 60 + now.getMinutes();
    return s < e ? n >= s && n < e : n >= s || n < e;
  }

  /** Decides whether dark mode should be on right now. */
  function resolveDark(settings, now, systemDark) {
    const s = { ...DEFAULTS, ...settings };
    if (s.mode === "dark") return true;
    if (s.mode === "light") return false;
    if (s.scheduleEnabled) return isInSchedule(now, s.scheduleStart, s.scheduleEnd);
    return Boolean(systemDark);
  }

  /** Keeps a number inside [min, max]; falls back if it isn't a number. */
  function clamp(value, min, max, fallback) {
    const n = Number(value);
    if (!Number.isFinite(n)) return fallback;
    return Math.min(max, Math.max(min, n));
  }

  const api = { DEFAULTS, toMinutes, isInSchedule, resolveDark, clamp };

  if (typeof module !== "undefined" && module.exports) {
    module.exports = api; // Node (tests)
  } else {
    root.GDDark = api; // Browser (content script, popup)
  }
})(typeof globalThis !== "undefined" ? globalThis : this);
