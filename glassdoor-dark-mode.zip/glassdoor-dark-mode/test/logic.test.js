const test = require("node:test");
const assert = require("node:assert/strict");
const { toMinutes, isInSchedule, resolveDark, clamp } = require("../src/logic.js");

const at = (hours, minutes = 0) => new Date(2026, 0, 1, hours, minutes);

test("toMinutes parses valid times and rejects bad ones", () => {
  assert.equal(toMinutes("00:00"), 0);
  assert.equal(toMinutes("19:30"), 1170);
  assert.equal(toMinutes("24:00"), null);
  assert.equal(toMinutes("12:60"), null);
  assert.equal(toMinutes("noon"), null);
});

test("overnight schedule (19:00 to 07:00)", () => {
  assert.equal(isInSchedule(at(20), "19:00", "07:00"), true);
  assert.equal(isInSchedule(at(3), "19:00", "07:00"), true);
  assert.equal(isInSchedule(at(12), "19:00", "07:00"), false);
  assert.equal(isInSchedule(at(19, 0), "19:00", "07:00"), true, "start is inclusive");
  assert.equal(isInSchedule(at(7, 0), "19:00", "07:00"), false, "end is exclusive");
});

test("same-day schedule (09:00 to 17:00)", () => {
  assert.equal(isInSchedule(at(10), "09:00", "17:00"), true);
  assert.equal(isInSchedule(at(18), "09:00", "17:00"), false);
});

test("empty or invalid schedules are never active", () => {
  assert.equal(isInSchedule(at(10), "09:00", "09:00"), false);
  assert.equal(isInSchedule(at(10), "bad", "17:00"), false);
});

test("explicit modes ignore system theme and schedule", () => {
  assert.equal(resolveDark({ mode: "dark" }, at(12), false), true);
  assert.equal(resolveDark({ mode: "light" }, at(12), true), false);
});

test("auto mode follows the system theme by default", () => {
  assert.equal(resolveDark({ mode: "auto" }, at(12), true), true);
  assert.equal(resolveDark({ mode: "auto" }, at(12), false), false);
});

test("auto mode with a schedule ignores the system theme", () => {
  const settings = { mode: "auto", scheduleEnabled: true, scheduleStart: "19:00", scheduleEnd: "07:00" };
  assert.equal(resolveDark(settings, at(22), false), true);
  assert.equal(resolveDark(settings, at(12), true), false);
});

test("clamp limits values and handles junk", () => {
  assert.equal(clamp(200, 50, 150, 100), 150);
  assert.equal(clamp(10, 50, 150, 100), 50);
  assert.equal(clamp("abc", 50, 150, 100), 100);
});
